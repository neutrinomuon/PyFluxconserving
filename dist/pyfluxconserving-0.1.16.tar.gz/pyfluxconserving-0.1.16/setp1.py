import os
import subprocess
from setuptools import setup, find_packages
from setuptools.command.build_ext import build_ext

class BuildFortran(build_ext):
    def run(self):
        fortran_sources = [
            "src/fortran/DataTypes.f90",
            "src/fortran/AkimaSpline.f90",
            "src/fortran/Interpolado.f90",
            "src/fortran/LINdexerpol.f90",
            "src/fortran/LINinterpol.f90",
            "src/fortran/SPLINE1DArr.f90",
            "src/fortran/SPLINE3DFor.f90",
            "src/fortran/FluxConSpec.f90",
        ]

        output_module = "flib"

        cmd = [
            "python3", "-m", "numpy.f2py",
            "-c",
            "-m", output_module,
            "--f90exec=gfortran",
            "--f90flags=-O3",
        ] + fortran_sources

        print("\n=== Compiling Fortran with f2py ===")
        print(" ".join(cmd))
        subprocess.check_call(cmd)

        # Move compiled module into the package directory
        so_file = [f for f in os.listdir(".") if f.startswith(output_module) and f.endswith(".so")][0]

        os.makedirs("src/python/PyFluxconserving", exist_ok=True)
        dest = os.path.join("src/python/PyFluxconserving", so_file)
        print(f"\n=== Installing {so_file} to {dest} ===")
        os.rename(so_file, dest)

        super().run()

setup(
    name="PyFluxconserving",
    version="0.1",
    packages=find_packages(where="src/python"),
    package_dir={"": "src/python"},
    install_requires=[
        "numpy>=1.24",
        "scipy",
    ],
    include_package_data=True,
    cmdclass={"build_ext": BuildFortran},
)
